package Caw_studio_Maven;

public class TableClass {

}
